## Relatório TP3
[Relatório TP3](TS___tp3.pdf)

## Abordagem prática da aplicação

As aplicações desenvolvidas são de fácil maneio porem temos algumas limitações com quais utilizadores de sistema podem ser usados pois temos certificados limitados, assim o nosso serviço esta limitado aos utilizadores de sistema CLI1, CLI2, CLI2 e server.
Os utilizadores podem ser criados com a Aplicação ClinteStarter.py, apenas o servidor é necessario que seja criado recorrendo ao cofigo ('sudo adduser server')
Na ultima secção do nosso relatorio "Testes ao serviço" temos um guia detalha das operações do nosso sistema, que devem ser levadas como exemplo para testes ao nosso serviço.
